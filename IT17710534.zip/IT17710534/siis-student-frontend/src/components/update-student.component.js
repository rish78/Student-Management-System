import React, { Component } from 'react';
import axios from 'axios';

export default class UpdateStudent extends Component {

    constructor(props) {
        super(props);

        this.onChangeStudentFName = this.onChangeStudentFName.bind(this);
        this.onChangeStudentEmail = this.onChangeStudentEmail.bind(this);
        this.onChangeStudentRegNo = this.onChangeStudentFName.bind(this);
        this.onChangeStudentCYear = this.onChangeStudentCYear.bind(this);
        this.onChangeStudentCSem = this.onChangeStudentCSem.bind(this);

        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            student_FName : '',
            student_email: '',
            student_RegNo : '',
            student_CYear : '',
            student_CSem :''
        }
    }

    componentDidMount() {
        axios.get('http://localhost:4000/students/'+ this.props.match.params.id)
            .then(response => {
                this.setState({
                    student_FName: response.data.student_FName,
                    student_email: response.data.student_email,
                    student_RegNo: response.data.student_RegNo,
                    student_CYear: response.data.student_CYear,
                    student_CSem: response.data.student_CSem,

                })   
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    
    onChangeStudentFName(e){
        this.setState({
            student_FName : e.target.value
        });
    }

    onChangeStudentEmail(e){
        this.setState({
            student_email : e.target.value
        });
    }

    onChangeStudentRegNo(e) {
        this.setState({
            student_RegNo : e.target.value
        });
    }

    onChangeStudentCYear(e) {
        this.setState({
            student_CYear : e.target.value
        });
    }
    
    onChangeStudentCSem(e) {
        this.setState({
            student_CSem : e.target.value
        });
    }


    onSubmit(e) {
        e.preventDefault();
        const obj = {
            student_FName: this.state.student_FName,
            student_email: this.state.student_email,
            student_RegNo: this.state.student_RegNo,
            student_CYear: this.state.student_CYear,
            student_CSem: this.state.student_CSem,

        };
        console.log(obj);
        axios.post('http://localhost:4000/students/update/'+ this.props.match.params.id, obj)
            .then(res => console.log(res.data));
        
        this.props.history.push('/');
    }

    render() {
        return (
            <div>
                <h3 align="center">Update Students</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group"> 
                        <label>Full Name </label>
                        <input  type="text"
                                className="form-control"
                                value={this.state.student_FName}
                                onChange={this.onChangeStudentFName}
                                />
                    </div>
                    <div className="form-group">
                        <label>Email: </label>
                        <input 
                                type="text" 
                                className="form-control"
                                value={this.state.student_email}
                                onChange={this.onChangeStudentEmail}
                                />
                    </div>
                    <div className="form-group">
                        <label>Registration Number: </label>
                        <input 
                                type="text" 
                                className="form-control"
                                value={this.state.student_RegNo}
                                onChange={this.onChangeStudentRegNo}
                                />
                    </div>
                    <div className="form-group">
                        <label>Current Year: </label>
                        <input 
                                type="text" 
                                className="form-control"
                                value={this.state.student_CYear}
                                onChange={this.onChangeStudentCYear}
                                />
                    </div>
                    <div className="form-group">
                        <label>Current Semester: </label>
                        <input 
                                type="text" 
                                className="form-control"
                                value={this.state.student_CSem}
                                onChange={this.onChangeStudentCSem}
                                />
                    </div>
                    

                    <br />

                    <div className="form-group">
                        <input type="submit" value="Update student" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}