const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const studentRoutes = express.Router();
const PORT = 4000;

let Student = require('./student.model');

app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/students', { useNewUrlParser: true });
const connection = mongoose.connection;

connection.once('open', function() {
    console.log("MongoDB database connection established successfully");
})

studentRoutes.route('/').get(function(req, res) {
    Student.find(function(err, students) {
        if (err) {
            console.log(err);
        } else {
            res.json(students);
        }
    });
});



studentRoutes.route('/:id').get(function(req, res) {
    let id = req.params.id;
    Student.findById(id, function(err, student) {
        res.json(student);
    });
});

studentRoutes.route('/update/:id').post(function(req, res) {
    Student.findById(req.params.id, function(err, student) {
        if (!student)
            res.status(404).send("data is not found");
        else
            student.student_FName = req.body.student_FName;
            student.student_Email = req.body.student_Email;
            student.student_RegNo = req.body.student_RegNo;
            student.student_CYear = req.body.student_CYear;
            student.student_CSem = req.body.student_CSem;

            student.save().then(student => {
                res.json('Student updated!');
            })
            .catch(err => {
                res.status(400).send("Update not possible");
            });
    });
});

studentRoutes.route('/add').post(function(req, res) {
    let student = new Student(req.body);
    student.save()
        .then(student => {
            res.status(200).json({'student': 'student added successfully'});
        })
        .catch(err => {
            res.status(400).send('adding new student failed');
        });
});

app.use('/students', studentRoutes);

app.listen(PORT, function() {
    console.log("Server is running on Port: " + PORT);
});